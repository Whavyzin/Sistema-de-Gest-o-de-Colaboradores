<?php
    session_start();
if(isset($_POST['usuario']) && isset($_POST['senha'])){
    if($_POST['usuario'] == "admin" && $_POST['senha'] == "1234"){
        $_SESSION['logado'] = true; header("Location: index.php"); exit; }else{
        $erro = "Usuário ou senha inválidos!";
    }
} 
?>
<!DOCTYPE html> 
<html>
    <head>
        <title>
            Login - RHyos
        </title> 
        <style> 
            body{ 
                margin:0; min-height:100vh; background:linear-gradient(135deg,#020617,#0f172a,#1e293b); color:white; font-family:Arial; display:flex; justify-content:center; align-items:center;
            }
            form{
                background:#1e293b; width:350px; padding:30px; border-radius:18px; box-shadow:0 10px 25px rgba(0,0,0,0.5);
            } h1{
                text-align:center; color:#38bdf8; 
            } h2{
                text-align:center;
                color:#cbd5e1;
                margin-top:20px;
                margin-bottom:25px;
            } input{
                width:100%; padding:12px; margin:10px 0; border:none; border-radius:10px; box-sizing:border-box; 
            } input[type=submit]{
                background:#38bdf8; color:#020617; font-weight:bold;cursor:pointer; transition:0.3s;
            } input[type=submit]:hover{ 
                transform:translateY(-3px); background:#67e8f9;
            } p{ color:#ef4444; text-align:center;
            } label{
                color:white;
            } </style>
    </head>
    <body>
        <form method="POST">
     <h1>
         RHyos
            </h1>
            <h2>
                Login
            </h2>
            <label>
                Usuário:
            </label> 
            <input type="text" name="usuario">
            <label>
                Senha:
            </label>
            <input type="password" name="senha">
            <input type="submit" value="Entrar">
            <?php
            if(isset($erro)){
                echo "<p>$erro</p>";
            }
            ?>
        </form> 
    </body> 
</html>